import * as XLSX from 'xlsx';

// A simple interface for type safety, mirroring your Java POJO
export interface ProductData {
  pName: string;
  pTitle: string;
  pCode: string;
  orgName: string;
  pStartDate: string; // Keep as string for validation
  endDate: string;
  releaseDate: string; // Keep as string for validation
}

// Function to validate a single product row
export const validateProduct = (product: ProductData, rowIndex: number): string[] => {
  const errors: string[] = [];
  const currentDate = new Date();

  // Helper to parse MM/dd/yyyy format to a Date object
  const parseDate = (dateStr: string): Date | null => {
    const parts = dateStr.split('/');
    if (parts.length === 3) {
      const day = parseInt(parts[1], 10);
      const month = parseInt(parts[0], 10);
      const year = parseInt(parts[2], 10);
      if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
        return new Date(year, month - 1, day);
      }
    }
    return null;
  };

  // 1. pName validation: Not null, & char length 5 or 9
  if (!product.pName) {
    errors.push(`Row ${rowIndex}: Product Name (pName) cannot be null.`);
  } else if (product.pName.length !== 5 && product.pName.length !== 9) {
    errors.push(`Row ${rowIndex}: Product Name (pName) must be 5 or 9 characters long.`);
  }

  // 2. pCode validation: Not null, & char length must be 6
  if (!product.pCode) {
    errors.push(`Row ${rowIndex}: Product Code (pCode) cannot be null.`);
  } else if (product.pCode.length !== 6) {
    errors.push(`Row ${rowIndex}: Product Code (pCode) must be exactly 6 characters long.`);
  }

  // 3. pStartDate validation: Not null, MM/dd/yyyy format, lesser than current date
  if (!product.pStartDate) {
    errors.push(`Row ${rowIndex}: Start Date (pStartDate) cannot be null.`);
  } else {
    const startDate = parseDate(product.pStartDate);
    if (!startDate) {
      errors.push(`Row ${rowIndex}: Start Date (pStartDate) format is invalid. Expected MM/dd/yyyy.`);
    } else if (startDate >= currentDate) {
      errors.push(`Row ${rowIndex}: Start Date (pStartDate) must be a date in the past.`);
    }
  }

  // 4. releaseDate validation: Not null, MM/dd/yyyy format, greater than current date
  if (!product.releaseDate) {
    errors.push(`Row ${rowIndex}: Release Date (releaseDate) cannot be null.`);
  } else {
    const releaseDate = parseDate(product.releaseDate);
    if (!releaseDate) {
      errors.push(`Row ${rowIndex}: Release Date (releaseDate) format is invalid. Expected MM/dd/yyyy.`);
    } else if (releaseDate <= currentDate) {
      errors.push(`Row ${rowIndex}: Release Date (releaseDate) must be a date in the future.`);
    }
  }

  return errors;
};