import React, { useState } from 'react';
import axios from 'axios';
import * as XLSX from 'xlsx';
import { ProductData, validateProduct } from '../utils/productValidation';

const ProductUploader: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [message, setMessage] = useState<string>('');
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [products, setProducts] = useState<ProductData[] | null>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files.length > 0) {
      const file = event.target.files[0];
      setSelectedFile(file);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      setMessage('Please select a file first.');
      return;
    }

    // Reset previous messages and errors
    setMessage('');
    setValidationErrors([]);
    setProducts(null);

    // --- CLIENT-SIDE VALIDATION ---
    const reader = new FileReader();
    reader.onload = (e) => {
      const data = new Uint8Array(e.target?.result as ArrayBuffer);
      const workbook = XLSX.read(data, { type: 'array' });

      // Assuming data is in the first sheet and starts from the 3rd row (index 2)
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const excelData: ProductData[] = XLSX.utils.sheet_to_json(worksheet, {
        header: ['pName', 'pTitle', 'pCode', 'orgName', 'pStartDate', 'endDate', 'releaseDate'],
        range: 2, // Start reading from the 3rd row
      });

      const allErrors: string[] = [];
      excelData.forEach((product, index) => {
        const errors = validateProduct(product, index + 3); // index + 3 to get the actual row number
        if (errors.length > 0) {
          allErrors.push(...errors);
        }
      });

      if (allErrors.length > 0) {
        setValidationErrors(allErrors);
        setMessage('Client-side validation failed. Please correct the errors in the file.');
        return; // Stop the upload process
      }
      
      // If validation passes, proceed with the actual API upload
      performApiUpload(selectedFile);
    };
    reader.readAsArrayBuffer(selectedFile);
  };

  const performApiUpload = async (file: File) => {
    const formData = new FormData();
    formData.append('file', file);

    setMessage('Uploading to server...');
    try {
      const response = await axios.post<ProductData[]>('http://localhost:8585/api/products/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      setMessage('File uploaded and validated successfully on server!');
      setProducts(response.data);
    } catch (error) {
      if (axios.isAxiosError(error) && error.response) {
        setMessage(`Server Error: ${error.response.data}`);
      } else {
        setMessage('An unexpected error occurred.');
      }
      setProducts(null);
    }
  };

  return (
    <div>
      <h2>Product XLSX Uploader</h2>
      <div>
        <input type="file" accept=".xlsx" onChange={handleFileChange} />
        <button onClick={handleUpload} disabled={!selectedFile}>
          Upload
        </button>
      </div>
      {message && <p>{message}</p>}
      {validationErrors.length > 0 && (
        <div>
          <h3>Validation Errors</h3>
          <ul>
            {validationErrors.map((error, index) => (
              <li key={index}>{error}</li>
            ))}
          </ul>
        </div>
      )}
      {products && (
        <div>
          <h3>Validated Products (from server)</h3>
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Title</th>
                <th>Code</th>
                <th>Start Date</th>
                <th>Release Date</th>
              </tr>
            </thead>
            <tbody>
              {products.map((product, index) => (
                <tr key={index}>
                  <td>{product.pName}</td>
                  <td>{product.pTitle}</td>
                  <td>{product.pCode}</td>
                  <td>{product.pStartDate}</td>
                  <td>{product.releaseDate}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default ProductUploader;