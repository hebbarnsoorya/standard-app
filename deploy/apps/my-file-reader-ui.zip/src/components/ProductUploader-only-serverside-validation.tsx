import React, { useState } from 'react';
import axios from 'axios';

interface Product {
  pName: string;
  pTitle: string;
  pCode: string;
  orgName: string;
  pStartDate: string;
  endDate: string;
  releaseDate: string;
}

const ProductUploader: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [message, setMessage] = useState<string>('');
  const [products, setProducts] = useState<Product[] | null>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files.length > 0) {
      setSelectedFile(event.target.files[0]);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      setMessage('Please select a file first.');
      return;
    }

    const formData = new FormData();
    formData.append('file', selectedFile);

    setMessage('Uploading...');
    setProducts(null);

    try {
      const response = await axios.post<Product[]>('http://localhost:8585/api/products/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      setMessage('File uploaded successfully!');
      setProducts(response.data);
    } catch (error) {
      if (axios.isAxiosError(error) && error.response) {
        setMessage(`Error: ${error.response.data}`);
      } else {
        setMessage('An unexpected error occurred.');
      }
      setProducts(null);
    }
  };

  return (
    <div>
      <h2>Product XLSX Uploader</h2>
      <div>
        <input type="file" accept=".xlsx" onChange={handleFileChange} />
        <button onClick={handleUpload} disabled={!selectedFile}>
          Upload
        </button>
      </div>
      {message && <p>{message}</p>}
      {products && (
        <div>
          <h3>Validated Products</h3>
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Title</th>
                <th>Code</th>
                <th>Start Date</th>
                <th>Release Date</th>
              </tr>
            </thead>
            <tbody>
              {products.map((product, index) => (
                <tr key={index}>
                  <td>{product.pName}</td>
                  <td>{product.pTitle}</td>
                  <td>{product.pCode}</td>
                  <td>{product.pStartDate}</td>
                  <td>{product.releaseDate}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default ProductUploader;