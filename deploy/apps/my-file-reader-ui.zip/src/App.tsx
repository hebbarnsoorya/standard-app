import React, { useState } from 'react';
import './App.css';
import ProductUploader from './components/ProductUploader';
import WelcomeMessage from './components/WelcomeMessage'; // Assuming this component exists

function App() {
  const [showUploader, setShowUploader] = useState(false);

  const handleStartUpload = () => {
    setShowUploader(true);
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Product Management</h1>
        {showUploader ? (
          // If showUploader is true, render the uploader
          <ProductUploader />
        ) : (
          // Otherwise, render the welcome message with a button
          <>
            <WelcomeMessage name={'Soorya'} age={0} />
            <button onClick={handleStartUpload}>
              Start Product Upload
            </button>
          </>
        )}
      </header>
    </div>
  );
}

export default App;